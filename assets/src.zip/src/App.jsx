import { useState, useEffect } from "react";
import { CSS, T } from "./constants/tokens";
import { GATE_DIFFICULTY, DAILY_WEIGHTS, ITEM_POOL, TIERS, itemShapeType, UPGRADE_MAX_LEVEL, upgradeCost, rankFromLevel } from "./constants/gameData";
import { rollLoot, rollDamage, rollMonsterDamage, maxPlayerHp, effectiveStats, gainExp, todayStr, weekKey } from "./constants/gameLogic";
import { LIMITS } from "./constants/gameData";
import { useSystemState } from "./hooks/useSystemState";

import { AmbientParticles, SignatureMark } from "./components/UI";
import { Preloader, Nav } from "./components/Preloader";
import { LevelUpToast, LootRevealModal } from "./components/Toasts";

import { HomePage } from "./pages/HomePage";
import { QuestListPage } from "./pages/QuestListPage";
import { StatsPage, RankPage, LootPage, StatusBar } from "./pages/OtherPages";

export default function App() {
  const [ready, setReady] = useState(false);
  const [page, setPage] = useState("HOME");
  const { state, loaded, update } = useSystemState();
  const [levelUpInfo, setLevelUpInfo] = useState(null);
  const [lootInfo, setLootInfo] = useState(null);
  const [showSig, setShowSig] = useState(false);
  const [combatFlash, setCombatFlash] = useState(null);

  // Clear combat flash after 1.3s
  useEffect(() => {
    if (!combatFlash) return;
    const t = setTimeout(() => setCombatFlash(null), 1300);
    return () => clearTimeout(t);
  }, [combatFlash]);

  // Ctrl+M signature toggle
  useEffect(() => {
    const onKeyDown = (e) => {
      if (e.ctrlKey && (e.key === "m" || e.key === "M")) {
        e.preventDefault();
        setShowSig((v) => !v);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  // ─── COMPLETE QUEST ─────────────────────────────────────────────────────────
  const completeQuest = (id) => {
    update((prev) => {
      const quest = prev.quests.find((q) => q.id === id);
      if (!quest || quest.completed) return prev;
      if (prev.stamina <= 0) return prev;

      const isGate = quest.type === "GATE";
      const gate = isGate ? (GATE_DIFFICULTY[quest.difficulty] || GATE_DIFFICULTY.NORMAL) : null;
      const staminaCost = gate ? gate.stamina : 1;

      // Gate attack limit per day
      const today = todayStr();
      if (isGate) {
        const attacksCount = prev.lastGateAttackDate === today ? (prev.gateAttacksToday || 0) : 0;
        if (attacksCount >= (prev.maxGateAttacksPerDay ?? 23)) {
          setCombatFlash({ questId: id, blocked: true, msg: "وصلت الحد اليومي للهجمات!", ts: Date.now() });
          return prev;
        }
      }

      // Cooldown check (8h)
      if (quest.lastCompletedAt && Date.now() - quest.lastCompletedAt < 8 * 60 * 60 * 1000) return prev;
      if (prev.stamina < staminaCost) return prev;

      // Hunter dead
      if (isGate && prev.playerHp <= 0) {
        setCombatFlash({ questId: id, blocked: true, ts: Date.now() });
        return prev;
      }

      let updatedQuest, dmgDealt = 0, crit = false, dmgTaken = 0;

      if (!isGate) {
        updatedQuest = { ...quest, completed: true, lastDate: todayStr(), lastCompletedAt: Date.now() };
      } else {
        const maxHp = quest.maxHp ?? gate.hp;
        const currentHp = quest.hp ?? maxHp;
        const hit = rollDamage(effectiveStats(prev).STR);
        dmgDealt = hit.dmg; crit = hit.crit;
        const newHp = Math.max(0, currentHp - dmgDealt);
        const isDead = newHp <= 0;
        dmgTaken = rollMonsterDamage(gate.monsterDmg);
        updatedQuest = { ...quest, hp: newHp, maxHp, completed: isDead, lastDate: todayStr(), lastCompletedAt: isDead ? Date.now() : quest.lastCompletedAt };
        setCombatFlash({ questId: id, dmg: dmgDealt, crit, dmgTaken, ts: Date.now() });
      }

      const quests = prev.quests.map((q) => q.id === id ? updatedQuest : q);
      let nextState = { ...prev, quests };

      // EXP
      const shouldGrantExp = !isGate || updatedQuest.completed;
      if (shouldGrantExp) {
        nextState = gainExp(nextState, quest.expReward);
        if (nextState._leveledUp > 0) {
          const prevRank = rankFromLevel(prev.level);
          const newRank = rankFromLevel(nextState.level);
          setLevelUpInfo({ newLevel: nextState.level, rank: newRank, rankChanged: prevRank.title !== newRank.title });
          nextState.potions = (nextState.potions || 0) + nextState._leveledUp;
        }
        delete nextState._leveledUp;
      }

      // Loot
      const loot = updatedQuest.completed
        ? rollLoot(isGate ? gate.dropChance : 0.16, isGate ? gate.weights : DAILY_WEIGHTS)
        : null;

      let finalState = nextState;
      if (loot) {
        const inventory = [...(finalState.inventory || [])];
        const idx = inventory.findIndex((it) => it.name === loot.name && it.tier === loot.tier);
        if (idx >= 0) inventory[idx] = { ...inventory[idx], qty: inventory[idx].qty + 1 };
        else inventory.push({ name: loot.name, tier: loot.tier, qty: 1 });
        finalState = { ...finalState, inventory };
        setLootInfo(loot);
      }

      const maxPHp = maxPlayerHp(effectiveStats(finalState));
      const newPlayerHp = isGate ? Math.max(0, prev.playerHp - dmgTaken) : prev.playerHp;
      const todayKey = todayStr();
      const prevAttacks = finalState.lastGateAttackDate === todayKey ? (finalState.gateAttacksToday || 0) : 0;

      return {
        ...finalState,
        stamina: Math.max(0, finalState.stamina - staminaCost),
        playerHp: Math.min(maxPHp, newPlayerHp),
        gateAttacksToday: isGate ? prevAttacks + 1 : (finalState.gateAttacksToday || 0),
        lastGateAttackDate: isGate ? todayKey : (finalState.lastGateAttackDate || null),
      };
    });
  };

  const usePotion = () => update((prev) => {
    if (prev.potions <= 0) return prev;
    const max = maxPlayerHp(effectiveStats(prev));
    return { ...prev, potions: prev.potions - 1, playerHp: Math.min(max, prev.playerHp + 50) };
  });

  const restPlayer = () => update((prev) => {
    const max = maxPlayerHp(effectiveStats(prev));
    return { ...prev, playerHp: Math.min(max, prev.playerHp + 20) };
  });

  const deleteQuest = (id) => update((prev) => ({ ...prev, quests: prev.quests.filter((q) => q.id !== id) }));

  const addQuest = ({ title, expReward, frequency, type, difficulty }) => update((prev) => {
    const today = todayStr();
    let adds = prev.dailyQuestAdds || 0;
    if (prev.lastAddDate !== today) adds = 0;
    if (adds >= LIMITS.MAX_CUSTOM_QUESTS) return prev;

    let safeExp, hp = null, maxHp = null, diffKey = null;
    if (type === "GATE") {
      diffKey = difficulty && GATE_DIFFICULTY[difficulty] ? difficulty : "NORMAL";
      const gatePreset = GATE_DIFFICULTY[diffKey];
      safeExp = gatePreset.exp; hp = gatePreset.hp; maxHp = gatePreset.hp;
    } else {
      const maxExpMap = { DAILY: LIMITS.MAX_EXP_DAILY, WEEKLY: LIMITS.MAX_EXP_WEEKLY };
      safeExp = Math.min(Number(expReward) || 10, maxExpMap[type] || LIMITS.MAX_EXP_DAILY);
    }

    return {
      ...prev,
      dailyQuestAdds: adds + 1,
      lastAddDate: today,
      quests: [...prev.quests, { id: `q_custom_${Date.now()}`, title, type, expReward: safeExp, frequency, hp, maxHp, difficulty: diffKey, completed: false, lastDate: null }],
    };
  });

  const allocateStat = (key) => update((prev) => {
    if (prev.statPoints <= 0) return prev;
    return { ...prev, statPoints: prev.statPoints - 1, stats: { ...prev.stats, [key]: prev.stats[key] + 1 } };
  });

  // ─── EQUIP ──────────────────────────────────────────────────────────────────
  const equipItem = (key) => update((prev) => {
    const item = (prev.inventory || []).find((it) => `${it.tier}-${it.name}` === key);
    if (!item) return prev;
    const slot = itemShapeType(item.name);
    const equipped = { ...(prev.equipped || {}) };
    equipped[slot] = equipped[slot] === key ? null : key; // toggle equip/unequip
    return { ...prev, equipped };
  });

  // ─── UPGRADE (يستهلك نسخاً من العنصر نفسه كمواد) ────────────────────────────
  const upgradeItem = (key) => update((prev) => {
    const inv = prev.inventory || [];
    const idx = inv.findIndex((it) => `${it.tier}-${it.name}` === key);
    if (idx < 0) return prev;
    const item = inv[idx];
    const level = item.level || 0;
    if (level >= UPGRADE_MAX_LEVEL) return prev;
    const cost = upgradeCost(level);
    if (item.qty < cost + 1) return prev; // لازم يفضل نسخة واحدة على الأقل بعد الترقية
    const inventory = [...inv];
    inventory[idx] = { ...item, qty: item.qty - cost, level: level + 1 };
    return { ...prev, inventory };
  });

  // ─── COMBINE (3 من نفس الرتبة → 1 من رتبة أعلى) ─────────────────────────────
  const combineItems = (keys) => update((prev) => {
    if (keys.length !== 3) return prev;
    const inv = prev.inventory || [];
    const items = keys.map((k) => inv.find((it) => `${it.tier}-${it.name}` === k)).filter(Boolean);
    if (items.length !== 3) return prev;

    const tier = items[0].tier;
    if (!items.every((it) => it.tier === tier)) return prev;

    const tierIdx = TIERS.indexOf(tier);
    if (tierIdx < 0 || tierIdx >= TIERS.length - 1) return prev; // SSS أعلى رتبة، ما تُدمج
    const nextTier = TIERS[tierIdx + 1];

    let inventory = [...inv];
    let equipped = { ...(prev.equipped || {}) };

    for (const key of keys) {
      const idx = inventory.findIndex((it) => `${it.tier}-${it.name}` === key);
      if (idx < 0) continue;
      const newQty = inventory[idx].qty - 1;
      if (newQty <= 0) {
        for (const slot of Object.keys(equipped)) {
          if (equipped[slot] === key) equipped[slot] = null;
        }
        inventory.splice(idx, 1);
      } else {
        inventory[idx] = { ...inventory[idx], qty: newQty };
      }
    }

    const pool = ITEM_POOL[nextTier];
    const name = pool[Math.floor(Math.random() * pool.length)];
    const existingIdx = inventory.findIndex((it) => it.tier === nextTier && it.name === name);
    if (existingIdx >= 0) inventory[existingIdx] = { ...inventory[existingIdx], qty: inventory[existingIdx].qty + 1 };
    else inventory.push({ name, tier: nextTier, qty: 1, level: 0 });

    setLootInfo({ tier: nextTier, name }); // نفس نافذة فتح الهدية تظهر بعد الدمج
    return { ...prev, inventory, equipped };
  });

  return (
    <div style={{ minHeight: "100vh", background: T.bg, position: "relative" }}>
      <style>{CSS}</style>
      {ready && loaded && <AmbientParticles />}
      <SignatureMark visible={showSig} />
      {!ready && <Preloader onComplete={() => setReady(true)} />}
      {ready && !loaded && (
        <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", color: T.muted, fontFamily: "monospace", fontSize: 12 }}>
          SYNCING SYSTEM DATA...
        </div>
      )}
      {ready && loaded && (
        <div style={{ position: "relative", zIndex: 1 }}>
          <LevelUpToast info={levelUpInfo} onDone={() => setLevelUpInfo(null)} />
          <LootRevealModal info={lootInfo} onDone={() => setLootInfo(null)} />
          <Nav activePage={page} onNavigate={setPage} level={state.level} statPoints={state.statPoints} />

          {page === "HOME" && <HomePage state={state} onNavigate={setPage} />}
          {page === "QUESTS" && <QuestListPage title="السجل اليومي" subtitle="DAILY / WEEKLY QUESTS" types={["DAILY", "WEEKLY"]} addType="DAILY" state={state} onComplete={completeQuest} onDelete={deleteQuest} onAdd={addQuest} combatFlash={combatFlash} />}
          {page === "STATS" && <StatsPage state={state} onAllocate={allocateStat} />}
          {page === "GATES" && (
            <>
              <div style={{ maxWidth: 700, margin: "80px auto 0", padding: "0 24px" }}>
                <StatusBar state={state} />
              </div>
              <QuestListPage title="البوابات" subtitle="LONG-TERM GOALS" types={["GATE"]} addType="GATE" state={state} onComplete={completeQuest} onDelete={deleteQuest} onAdd={addQuest} onPotion={usePotion} onRest={restPlayer} combatFlash={combatFlash} />
            </>
          )}
          {page === "RANK" && <RankPage state={state} />}
          {page === "LOOT" && <LootPage state={state} onEquip={equipItem} onUpgrade={upgradeItem} onCombine={combineItems} />}
        </div>
      )}
    </div>
  );
}

import { T } from "../constants/tokens";
import { QuestCard, PlayerHpBar, AddQuestForm } from "../components/QuestCard";

export function QuestListPage({ title, subtitle, types, addType, state, onComplete, onDelete, onAdd, onPotion, onRest, combatFlash }) {
  const items = state.quests.filter((q) => types.includes(q.type));
  const isGatePage = types.includes("GATE");

  return (
    <div style={{ minHeight: "100vh", paddingTop: 80, padding: "80px 24px 40px", maxWidth: 700, margin: "0 auto", animation: "pageInRight 0.4s ease-out both" }}>
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontFamily: "monospace", fontSize: 10, letterSpacing: 4, color: T.purple, marginBottom: 8 }}>◈ {subtitle}</div>
        <h2 style={{ fontFamily: "'Orbitron', monospace", fontSize: 24, fontWeight: 700, color: T.text }}>{title}</h2>
      </div>

      {isGatePage && <PlayerHpBar state={state} onPotion={onPotion} onRest={onRest} />}

      <div style={{ marginBottom: 16 }}>
        <AddQuestForm defaultType={addType} onAdd={onAdd} />
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {items.length === 0 && (
          <div style={{ color: T.muted, fontSize: 13, textAlign: "center", padding: 30 }}>
            لا توجد مهام حالياً — أضف واحدة بالأعلى
          </div>
        )}
        {items.map((q) => (
          <QuestCard key={q.id} quest={q} onComplete={onComplete} onDelete={onDelete} flash={combatFlash} />
        ))}
      </div>
    </div>
  );
}

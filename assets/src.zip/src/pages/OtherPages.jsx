import { useState } from "react";
import { T, glass } from "../constants/tokens";
import {
  STAT_KEYS, RANK_TIERS, TIERS, TIER_COLOR, TIER_TOP, rankFromLevel,
  SLOT_STAT, SLOT_LABEL, SLOT_ORDER, itemShapeType, UPGRADE_MAX_LEVEL, upgradeCost,
} from "../constants/gameData";
import { HudCorners, RankBadge, ExpBar } from "../components/UI";
import { ItemIcon } from "../components/LootIcons";
import { maxPlayerHp, effectiveStats, getEquipmentBonuses, itemBonusValue, todayStr } from "../constants/gameLogic";

// ─── STATUS BAR (HP + Stamina + Gate Attacks) ─────────────────────────────────
export function StatusBar({ state }) {
  const maxHp = maxPlayerHp(effectiveStats(state));
  const hpPct = Math.max(0, Math.min(100, (state.playerHp / maxHp) * 100));
  const stPct = Math.max(0, Math.min(100, (state.stamina / 100) * 100));
  const hpCol = hpPct > 50 ? "#10b981" : hpPct > 20 ? "#eab308" : "#ef4444";
  const today = todayStr();
  const attacks = state.lastGateAttackDate === today ? (state.gateAttacksToday || 0) : 0;
  const maxAtk = state.maxGateAttacksPerDay ?? 23;

  const bars = [
    { label: "HP", val: state.playerHp, max: maxHp, pct: hpPct, color: hpCol, icon: "❤️" },
    { label: "STAMINA", val: state.stamina, max: 10000, pct: stPct, color: T.blue, icon: "⚡" },
  ];

  return (
    <div style={{ ...glass({ padding: "14px 18px" }), marginBottom: 16, display: "flex", gap: 20, flexWrap: "wrap", alignItems: "center" }}>
      {bars.map(({ label, val, max, pct, color, icon }) => (
        <div key={label} style={{ flex: "1 1 160px", minWidth: 140 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
            <span style={{ fontFamily: "monospace", fontSize: 10, letterSpacing: 2, color: T.muted }}>{icon} {label}</span>
            <span style={{ fontFamily: "monospace", fontSize: 11, color, fontWeight: 700 }}>{val} / {max}</span>
          </div>
          <div style={{ height: 8, background: "rgba(255,255,255,0.07)", borderRadius: 99, overflow: "hidden" }}>
            <div style={{ height: "100%", width: `${pct}%`, background: color, borderRadius: 99, transition: "width .3s ease, background .3s ease" }} />
          </div>
        </div>
      ))}

      {/* Gate attacks today */}
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6, paddingLeft: 8, borderLeft: `1px solid ${T.border}` }}>
        <span style={{ fontFamily: "monospace", fontSize: 10, letterSpacing: 2, color: T.muted }}>🗡️ هجمات البوابة</span>
        <div style={{ display: "flex", gap: 5 }}>
          {Array.from({ length: maxAtk }).map((_, i) => (
            <div key={i} style={{
              width: 22, height: 22, borderRadius: 5,
              background: i < attacks ? T.purple : "rgba(139,92,246,0.12)",
              border: `1px solid ${i < attacks ? T.purple : T.border}`,
              boxShadow: i < attacks ? `0 0 8px ${T.purple}60` : "none",
              transition: "all 0.2s",
            }} />
          ))}
        </div>
        <span style={{ fontFamily: "monospace", fontSize: 10, color: attacks >= maxAtk ? T.red : T.muted }}>
          {attacks}/{maxAtk} {attacks >= maxAtk ? "— انتهت اليوم" : ""}
        </span>
      </div>
    </div>
  );
}

// ─── STATS PAGE ───────────────────────────────────────────────────────────────
export function StatsPage({ state, onAllocate }) {
  const bonuses = getEquipmentBonuses(state);
  return (
    <div style={{ minHeight: "100vh", paddingTop: 80, padding: "80px 24px 40px", maxWidth: 600, margin: "0 auto", animation: "pageInRight 0.4s ease-out both" }}>
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontFamily: "monospace", fontSize: 10, letterSpacing: 4, color: T.purple, marginBottom: 8 }}>◈ HUNTER STATS</div>
        <h2 style={{ fontFamily: "'Orbitron', monospace", fontSize: 24, fontWeight: 700, color: T.text }}>الإحصائيات</h2>
        <div style={{ marginTop: 10, fontFamily: "monospace", fontSize: 12, color: state.statPoints > 0 ? T.gold : T.muted }}>
          نقاط متاحة للتوزيع: {state.statPoints}
        </div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {STAT_KEYS.map((k) => {
          const base = state.stats[k];
          const bonus = bonuses[k];
          return (
            <div key={k} style={{ ...glass({ padding: "14px 18px" }), display: "flex", alignItems: "center", gap: 14 }}>
              <div style={{ width: 70, fontFamily: "'Orbitron', monospace", fontSize: 13, fontWeight: 700, color: T.purple }}>{k}</div>
              <div style={{ flex: 1 }}>
                <ExpBar exp={base} expToNext={Math.max(50, base + 10)} color={T.cyan} height={6} />
              </div>
              <div style={{ width: 56, textAlign: "center", fontFamily: "monospace", fontSize: 14, color: T.text }}>
                {base}{bonus > 0 && <span style={{ color: T.gold, fontSize: 11 }}> +{bonus}</span>}
              </div>
              <button
                onClick={() => onAllocate(k)}
                disabled={state.statPoints <= 0}
                style={{
                  width: 28, height: 28, borderRadius: 6, border: `1px solid ${T.border}`,
                  background: state.statPoints > 0 ? "rgba(139,92,246,0.15)" : "transparent",
                  color: state.statPoints > 0 ? T.purple : T.muted,
                  cursor: state.statPoints > 0 ? "pointer" : "default", fontWeight: 900,
                }}
              >+</button>
            </div>
          );
        })}
      </div>
      {Object.values(bonuses).some((v) => v > 0) && (
        <div style={{ marginTop: 16, fontFamily: "monospace", fontSize: 11, color: T.muted, textAlign: "center" }}>
          الأرقام الصفراء بونص من العناصر المجهّزة بالمخزون 🎽
        </div>
      )}
    </div>
  );
}

// ─── RANK PAGE ────────────────────────────────────────────────────────────────
export function RankPage({ state }) {
  const rank = rankFromLevel(state.level);
  return (
    <div style={{ minHeight: "100vh", paddingTop: 80, padding: "80px 24px 40px", maxWidth: 600, margin: "0 auto", animation: "pageInRight 0.4s ease-out both" }}>
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontFamily: "monospace", fontSize: 10, letterSpacing: 4, color: T.purple, marginBottom: 8 }}>◈ HUNTER RANK</div>
        <h2 style={{ fontFamily: "'Orbitron', monospace", fontSize: 24, fontWeight: 700, color: T.text }}>التصنيف</h2>
      </div>

      <div style={{ ...glass({ padding: 32 }), textAlign: "center", marginBottom: 24, position: "relative", overflow: "hidden" }}>
        <HudCorners color={rank.color} size={14} />
        {rank.top && (
          <div style={{
            position: "absolute", inset: -40, opacity: 0.15, pointerEvents: "none",
            background: `conic-gradient(from 0deg, ${rank.color}, transparent, ${rank.color})`,
            animation: "auraSpin 8s linear infinite",
          }} />
        )}
        <div style={{ position: "relative" }}><RankBadge rank={rank} size={36} /></div>
        <div style={{ fontFamily: "monospace", fontSize: 12, color: T.muted, marginTop: 10, position: "relative" }}>
          المستوى الحالي: {state.level}
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {RANK_TIERS.slice().reverse().map((r) => (
          <div key={r.title} style={{
            ...glass({ padding: "12px 16px" }),
            display: "flex", justifyContent: "space-between", alignItems: "center",
            opacity: state.level >= r.min ? 1 : 0.4,
            border: rank.title === r.title ? `1px solid ${r.color}` : `1px solid ${T.border}`,
          }}>
            <RankBadge rank={r} size={14} />
            <span style={{ fontFamily: "monospace", fontSize: 11, color: T.muted }}>يتطلب مستوى {r.min}+</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── LOOT CARD (pseudo-3D icon + tilt + equip/upgrade/combine) ───────────────
function LootCard({ tier, name, qty, level, idx, keyId, isEquipped, onEquip, onUpgrade, selected, onToggleSelect }) {
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const color = TIER_COLOR[tier];
  const isTop = !!TIER_TOP[tier];
  const uid = `${tier}-${idx}`;
  const slot = itemShapeType(name);
  const statKey = SLOT_STAT[slot];
  const cost = upgradeCost(level || 0);
  const canUpgrade = (level || 0) < UPGRADE_MAX_LEVEL && qty >= cost + 1;

  const onMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({ x: py * -14, y: px * 14 });
  };
  const onLeave = () => setTilt({ x: 0, y: 0 });

  return (
    <div
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      style={{
        ...glass({ padding: "20px 14px 14px" }),
        position: "relative",
        animation: `fadeUp 0.35s ease-out ${idx * 0.04}s both`,
        transformStyle: "preserve-3d",
        perspective: 600,
        transform: `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)`,
        transition: "transform 0.25s cubic-bezier(.22,1,.36,1), box-shadow 0.25s, border-color .2s",
        display: "flex", flexDirection: "column", alignItems: "center", gap: 8,
        border: selected ? `1px solid ${T.purple}` : undefined,
        boxShadow: selected ? `0 0 0 1px ${T.purple}80, 0 10px 30px rgba(0,0,0,.35)` : undefined,
      }}
    >
      <HudCorners size={9} color={color} />
      {isTop && (
        <div style={{ position: "absolute", inset: -1, borderRadius: 14, opacity: 0.14, pointerEvents: "none", background: `conic-gradient(from 0deg, ${color}, transparent, ${color})`, animation: "auraSpin 9s linear infinite" }} />
      )}

      {/* تحديد للدمج */}
      <button
        onClick={() => onToggleSelect(keyId)}
        title="تحديد للدمج"
        style={{
          position: "absolute", top: 8, left: 8, width: 18, height: 18, borderRadius: 4,
          border: `1px solid ${selected ? T.purple : T.border}`,
          background: selected ? T.purple : "rgba(0,0,0,0.25)",
          color: "#04000f", fontSize: 11, fontWeight: 900, cursor: "pointer",
          display: "flex", alignItems: "center", justifyContent: "center", zIndex: 2,
        }}
      >{selected ? "✓" : ""}</button>

      <div style={{ position: "absolute", top: 8, right: 8, fontFamily: "monospace", fontSize: 11, color: T.gold, fontWeight: 700, background: "rgba(0,0,0,0.35)", borderRadius: 6, padding: "2px 7px" }}>×{qty}</div>

      <div style={{ position: "relative", width: 60, height: 60, display: "flex", alignItems: "center", justifyContent: "center", marginTop: 8 }}>
        {isEquipped && (
          <div style={{ position: "absolute", inset: -6, borderRadius: "50%", border: `2px solid ${T.gold}`, boxShadow: `0 0 14px ${T.gold}80`, animation: "pulse-ring 2s ease-in-out infinite" }} />
        )}
        <div style={{ position: "absolute", bottom: -2, width: 42, height: 9, borderRadius: "50%", background: color, opacity: 0.35, filter: "blur(6px)" }} />
        <div style={{ animation: "itemFloat 3.6s ease-in-out infinite" }}>
          <ItemIcon name={name} tier={tier} uid={uid} size={52} />
        </div>
      </div>

      <span style={{
        fontFamily: "'Orbitron', monospace", fontWeight: 900, fontSize: 13,
        ...(tier === "SSS"
          ? { backgroundImage: `linear-gradient(90deg, ${T.gold}, ${T.purple}, ${T.cyan}, ${T.gold})`, backgroundSize: "200% auto", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text", animation: "shimmerText 2.6s linear infinite" }
          : { color, textShadow: isTop ? `0 0 10px ${color}80` : "none" }),
      }}>[{tier}]{level > 0 ? ` +${level}` : ""}</span>

      <div style={{ fontSize: 12.5, fontWeight: 600, color: T.text, textAlign: "center" }}>{name}</div>
      <div style={{ fontFamily: "monospace", fontSize: 10, color: T.muted }}>{SLOT_LABEL[slot]} · {statKey}+{itemBonusValue({ tier, level })}</div>

      <div style={{ display: "flex", gap: 6, width: "100%", marginTop: 4 }}>
        <button
          onClick={() => onEquip(keyId)}
          style={{
            flex: 1, padding: "6px 4px", borderRadius: 6, border: `1px solid ${isEquipped ? T.gold : T.border}`,
            background: isEquipped ? "rgba(251,191,36,0.15)" : "rgba(255,255,255,0.04)",
            color: isEquipped ? T.gold : T.text, fontSize: 10.5, fontWeight: 700, cursor: "pointer",
          }}
        >{isEquipped ? "✓ مجهّز" : "تجهيز"}</button>
        <button
          onClick={() => canUpgrade && onUpgrade(keyId)}
          disabled={!canUpgrade}
          title={`يستهلك ${cost} نسخة`}
          style={{
            flex: 1, padding: "6px 4px", borderRadius: 6, border: `1px solid ${T.border}`,
            background: canUpgrade ? "rgba(34,211,238,0.12)" : "rgba(255,255,255,0.03)",
            color: canUpgrade ? T.cyan : T.muted, fontSize: 10.5, fontWeight: 700,
            cursor: canUpgrade ? "pointer" : "default",
          }}
        >⤴ ترقية (-{cost})</button>
      </div>
    </div>
  );
}

// ─── EQUIP SLOTS SUMMARY ──────────────────────────────────────────────────────
function EquipSlots({ state }) {
  const equipped = state.equipped || {};
  const inv = state.inventory || [];
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(105px,1fr))", gap: 8, marginBottom: 20 }}>
      {SLOT_ORDER.map((slot) => {
        const key = equipped[slot];
        const item = key ? inv.find((it) => `${it.tier}-${it.name}` === key) : null;
        const color = item ? TIER_COLOR[item.tier] : T.muted;
        return (
          <div key={slot} style={{ ...glass({ padding: "10px 10px" }), textAlign: "center", position: "relative" }}>
            <HudCorners size={7} color={color} />
            <div style={{ fontFamily: "monospace", fontSize: 9, color: T.muted, letterSpacing: 1, marginBottom: 6 }}>{SLOT_LABEL[slot]} · {SLOT_STAT[slot]}</div>
            {item ? (
              <>
                <div style={{ display: "flex", justifyContent: "center", marginBottom: 4 }}>
                  <ItemIcon name={item.name} tier={item.tier} uid={`slot-${slot}`} size={32} />
                </div>
                <div style={{ fontSize: 11, color: T.gold, fontWeight: 700 }}>+{itemBonusValue(item)}</div>
              </>
            ) : (
              <div style={{ fontSize: 11, color: T.muted, padding: "12px 0" }}>فاضي</div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── LOOT PAGE ────────────────────────────────────────────────────────────────
export function LootPage({ state, onEquip, onUpgrade, onCombine }) {
  const [selected, setSelected] = useState([]);
  const inv = state.inventory || [];
  const sorted = TIERS.slice().reverse().flatMap((tier) => inv.filter((it) => it.tier === tier));
  const equipped = state.equipped || {};
  const equippedKeys = new Set(Object.values(equipped).filter(Boolean));

  const toggleSelect = (key) => {
    setSelected((prev) => {
      if (prev.includes(key)) return prev.filter((k) => k !== key);
      if (prev.length >= 3) return prev;
      return [...prev, key];
    });
  };

  const selectedItems = selected.map((k) => inv.find((it) => `${it.tier}-${it.name}` === k)).filter(Boolean);
  const sameTier = selectedItems.length === 3 && selectedItems.every((it) => it.tier === selectedItems[0].tier);
  const tierIdx = selectedItems[0] ? TIERS.indexOf(selectedItems[0].tier) : -1;
  const canCombine = sameTier && tierIdx >= 0 && tierIdx < TIERS.length - 1;

  let hint = null;
  if (selected.length === 3) {
    if (!sameTier) hint = "اختر 3 من نفس الرتبة";
    else if (!canCombine) hint = "هذي أعلى رتبة (SSS) — ما تُدمج أكثر";
  }

  const doCombine = () => {
    if (!canCombine) return;
    onCombine(selected);
    setSelected([]);
  };

  return (
    <div style={{ minHeight: "100vh", paddingTop: 80, padding: "80px 24px 100px", maxWidth: 760, margin: "0 auto", animation: "pageInRight 0.4s ease-out both" }}>
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontFamily: "monospace", fontSize: 10, letterSpacing: 4, color: T.purple, marginBottom: 8 }}>◈ INVENTORY</div>
        <h2 style={{ fontFamily: "'Orbitron', monospace", fontSize: 24, fontWeight: 700, color: T.text }}>المخزون</h2>
        <div style={{ marginTop: 8, fontFamily: "monospace", fontSize: 12, color: T.muted }}>
          جهّز عنصر من كل نوع يرفع الستات المرتبطة فعلياً. رقّي عنصر باستهلاك نسخ منه. اختر 3 من نفس الرتبة لدمجهم لرتبة أعلى.
        </div>
      </div>

      <EquipSlots state={state} />

      {sorted.length === 0 ? (
        <div style={{ color: T.muted, fontSize: 13, textAlign: "center", padding: 40 }}>
          لسا ما نزل لك أي عنصر — أكمل مهام أو بوابات وجرّب حظك
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(165px, 1fr))", gap: 12 }}>
          {sorted.map((it, i) => {
            const key = `${it.tier}-${it.name}`;
            return (
              <LootCard
                key={key}
                keyId={key}
                tier={it.tier}
                name={it.name}
                qty={it.qty}
                level={it.level || 0}
                idx={i}
                isEquipped={equippedKeys.has(key)}
                onEquip={onEquip}
                onUpgrade={onUpgrade}
                selected={selected.includes(key)}
                onToggleSelect={toggleSelect}
              />
            );
          })}
        </div>
      )}

      {selected.length > 0 && (
        <div style={{ position: "fixed", bottom: 24, left: "50%", transform: "translateX(-50%)", zIndex: 150, animation: "popIn 0.3s ease-out both" }}>
          <div style={{ ...glass({ padding: "14px 22px" }), display: "flex", alignItems: "center", gap: 14, border: `1px solid ${canCombine ? T.purple : T.border}`, boxShadow: canCombine ? `0 0 30px ${T.purple}50` : "none" }}>
            <span style={{ fontFamily: "monospace", fontSize: 12, color: T.text }}>محدد: {selected.length}/3</span>
            {hint && <span style={{ fontFamily: "monospace", fontSize: 11, color: T.red }}>{hint}</span>}
            <button
              onClick={doCombine}
              disabled={!canCombine}
              style={{
                padding: "8px 18px", borderRadius: 6, border: "none", cursor: canCombine ? "pointer" : "default",
                background: canCombine ? `linear-gradient(135deg, ${T.glow}, ${T.glowBlue})` : "rgba(255,255,255,0.06)",
                color: canCombine ? "#fff" : T.muted, fontWeight: 700, fontSize: 12,
              }}
            >🔥 دمج لرتبة أعلى</button>
            <button onClick={() => setSelected([])} style={{ background: "none", border: "none", color: T.muted, cursor: "pointer", fontSize: 12 }}>إلغاء</button>
          </div>
        </div>
      )}
    </div>
  );
}

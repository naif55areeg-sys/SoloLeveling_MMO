import { useEffect, useRef, useState } from "react";
import { T, glass } from "../constants/tokens";
import { STAT_KEYS, rankFromLevel } from "../constants/gameData";
import { HudCorners, RankBadge, ExpBar } from "../components/UI";

// ─── دَالَّةُ تَحْدِيدِ أَلْوَانِ الهَالَةِ الدِّينَامِيكِيَّةِ لِكُلِّ الرَّانْكَاتِ ──────────────────
function getRankColors(rank) {
  // استخراج العنوان النصي للرانك بشكل آمن سواء كان كائناً أو نصاً
  let title = "E-RANK";
  if (rank) {
    if (typeof rank === "string") {
      title = rank.toUpperCase();
    } else if (typeof rank === "object" && rank.title) {
      title = rank.title.toUpperCase();
    }
  }

  // بناء التدرجات والنيران بناءً على ألوان رانكاتك الرسمية بدقة
  if (title.includes("ABSOLUTE")) { // لفل 5000+
    return {
      base: "#1c1917", core: "#ffffff", spark: "#cbd5e1",
      glow: "rgba(255, 255, 255, 0.4)", aura: "rgba(255, 255, 255, 0.15)"
    };
  }
  if (title.includes("SHADOW-OVERLORD")) { // لفل 3000+
    return {
      base: "#1e1b4b", core: "#6d28d9", spark: "#a78bfa",
      glow: "rgba(109, 40, 217, 0.4)", aura: "rgba(109, 40, 217, 0.2)"
    };
  }
  if (title.includes("SHADOW-MONARCH")) { // لفل 2000+
    return {
      base: "#2e1065", core: "#7c3aed", spark: "#c084fc",
      glow: "rgba(124, 58, 237, 0.4)", aura: "rgba(124, 58, 237, 0.2)"
    };
  }
  if (title.includes("MONARCH-SUPREME")) { // لفل 1000+
    return {
      base: "#451a03", core: "#b45309", spark: "#fb923c",
      glow: "rgba(180, 83, 9, 0.4)", aura: "rgba(180, 83, 9, 0.2)"
    };
  }
  if (title.includes("MONARCH-GENERAL")) { // لفل 500+
    return {
      base: "#451a03", core: "#f59e0b", spark: "#fcd34d",
      glow: "rgba(245, 158, 11, 0.4)", aura: "rgba(245, 158, 11, 0.2)"
    };
  }
  if (title.includes("RULER-ELITE")) { // لفل 150+
    return {
      base: "#78350f", core: "#d97706", spark: "#fcd34d",
      glow: "rgba(217, 119, 6, 0.4)", aura: "rgba(217, 119, 6, 0.2)"
    };
  }
  if (title.includes("RULER")) { // لفل 80+
    return {
      base: "#451a03", core: "#fbbf24", spark: "#fef08a",
      glow: "rgba(251, 191, 36, 0.4)", aura: "rgba(251, 191, 36, 0.2)"
    };
  }
  if (title.includes("S+-RANK")) { // لفل 65+
    return {
      base: "#083344", core: "#67e8f9", spark: "#22d3ee",
      glow: "rgba(103, 232, 249, 0.4)", aura: "rgba(103, 232, 249, 0.2)"
    };
  }
  if (title.includes("S-RANK")) { // لفل 50+
    return {
      base: "#2e1065", core: T.purple, spark: "#d8b4fe",
      glow: "rgba(168, 85, 247, 0.4)", aura: "rgba(168, 85, 247, 0.2)"
    };
  }
  if (title.includes("A-RANK")) { // لفل 40+
    return {
      base: "#422006", core: T.gold, spark: "#fef08a",
      glow: "rgba(234, 179, 8, 0.4)", aura: "rgba(234, 179, 8, 0.2)"
    };
  }
  if (title.includes("B-RANK")) { // لفل 30+
    return {
      base: "#172554", core: T.blue, spark: "#93c5fd",
      glow: "rgba(59, 130, 246, 0.4)", aura: "rgba(59, 130, 246, 0.2)"
    };
  }
  if (title.includes("C-RANK")) { // لفل 20+
    return {
      base: "#042f2e", core: T.cyan, spark: "#67e8f9",
      glow: "rgba(6, 182, 212, 0.4)", aura: "rgba(6, 182, 212, 0.2)"
    };
  }
  if (title.includes("D-RANK")) { // لفل 10+
    return {
      base: "#1f2937", core: "#9ca3af", spark: "#e5e7eb",
      glow: "rgba(156, 163, 175, 0.3)", aura: "rgba(156, 163, 175, 0.15)"
    };
  }

  // E-RANK الافتراضي (لفل 1+)
  return {
    base: "#450a0a", core: T.red, spark: "#fca5a5",
    glow: "rgba(239, 68, 68, 0.4)", aura: "rgba(239, 68, 68, 0.15)"
  };
}

// ─── مَكُون الشَّخْصِيَّة مَعَ نِيرَانِ الرَّانْكِ الدِّينَامِيكِيَّةِ ───────────────
function SungJinWooWithManaCore({ rank, style }) {
  const [manaValue, setManaValue] = useState(4850);
  const colors = getRankColors(rank);

  useEffect(() => {
    const interval = setInterval(() => {
      setManaValue(prev => {
        const change = Math.floor(Math.random() * 11) - 5;
        const next = prev + change;
        return next > 5000 ? 5000 : next < 4700 ? 4700 : next;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{
      width: "260px",
      height: "260px",
      position: "relative",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      flexShrink: 0,
      animation: "floatAnimation 4s ease-in-out infinite",
      ...style,
    }}>

      <style>{`
        @keyframes floatAnimation {
          0% { transform: translateY(0px); }
          50% { transform: translateY(-8px); }
          100% { transform: translateY(0px); }
        }
        @keyframes rotateClockwise {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        @keyframes rotateCounterClockwise {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(-360deg); }
        }
        @keyframes shadowFlameWave {
          0%, 100% {
            transform: scale(1) rotate(0deg);
            border-radius: 42% 58% 45% 55% / 45% 45% 55% 55%;
          }
          33% {
            transform: scale(1.05, 1.1) rotate(2deg) skewX(-2deg);
            border-radius: 50% 50% 40% 60% / 40% 55% 45% 60%;
          }
          66% {
            transform: scale(0.97, 1.05) rotate(-2deg) skewX(2deg);
            border-radius: 45% 55% 50% 45% / 55% 40% 60% 45%;
          }
        }
        @keyframes particleRise {
          0% { transform: translateY(20px) translateX(0) scale(1); opacity: 0; }
          20% { opacity: 1; }
          80% { opacity: 0.8; }
          100% { transform: translateY(-120px) translateX(var(--x-move)) scale(0); opacity: 0; }
        }
      `}</style>

      {/* 🔥 [النار الأساسية الخلفية] */}
      <div style={{
        position: "absolute",
        width: "92%",
        height: "120%",
        bottom: "-10%",
        background: `linear-gradient(to top, rgba(0,0,0,0) 0%, ${colors.base} 30%, ${colors.core} 70%, transparent 100%)`,
        animation: "shadowFlameWave 4s ease-in-out infinite",
        filter: "blur(12px)",
        opacity: 0.7,
        mixBlendMode: "screen",
        zIndex: 1,
      }} />

      {/* 🔥 [ألسنة اللهب النيونية الساطعة] */}
      <div style={{
        position: "absolute",
        width: "82%",
        height: "130%",
        bottom: "-8%",
        background: `linear-gradient(to top, rgba(0,0,0,0) 10%, ${colors.core} 50%, ${colors.spark} 85%, transparent 100%)`,
        animation: "shadowFlameWave 2.8s ease-in-out infinite",
        filter: "blur(6px)",
        opacity: 0.6,
        mixBlendMode: "plus-lighter",
        zIndex: 2,
      }} />

      {/* ⚡ [شرارات النار المتطايرة الديناميكية بلون الرانك] */}
      <div style={{ position: "absolute", width: "100%", height: "100%", zIndex: 2, pointerEvents: "none" }}>
        {[
          { left: "25%", delay: "0s", size: "6px", x: "-20px", dur: "2.2s" },
          { left: "45%", delay: "0.5s", size: "4px", x: "15px", dur: "1.8s" },
          { left: "70%", delay: "1.1s", size: "5px", x: "-10px", dur: "2.5s" },
          { left: "35%", delay: "1.6s", size: "3px", x: "25px", dur: "2s" },
          { left: "60%", delay: "0.2s", size: "5px", x: "-15px", dur: "1.9s" }
        ].map((p, idx) => (
          <div
            key={idx}
            style={{
              position: "absolute",
              bottom: "10%",
              left: p.left,
              width: p.size,
              height: p.size,
              borderRadius: "50%",
              background: colors.core,
              boxShadow: `0 0 10px ${colors.core}, 0 0 20px ${colors.spark}`,
              animation: `particleRise ${p.dur} infinite linear`,
              animationDelay: p.delay,
              "--x-move": p.x,
            }}
          />
        ))}
      </div>

      {/* 🔮 حلقة النظام الخارجية */}
      <svg
        viewBox="0 0 200 200"
        style={{
          position: "absolute",
          width: "100%",
          height: "100%",
          animation: "rotateClockwise 25s linear infinite",
          opacity: 0.5,
          zIndex: 3
        }}
      >
        <circle cx="100" cy="100" r="92" fill="none" stroke={colors.core} strokeWidth="1" strokeDasharray="10 30" />
      </svg>

      {/* 🔮 حلقة النظام الداخلية ومؤشر الـ MP */}
      <svg
        viewBox="0 0 200 200"
        style={{
          position: "absolute",
          width: "86%",
          height: "86%",
          animation: "rotateCounterClockwise 15s linear infinite",
          opacity: 0.6,
          zIndex: 3
        }}
      >
        <circle cx="100" cy="100" r="80" fill="none" stroke={colors.core} strokeWidth="0.8" strokeDasharray="6 12" />
        <circle cx="100" cy="100" r="80" fill="none" stroke={colors.core} strokeWidth="2.5" strokeDasharray="280 400" strokeLinecap="round" />
      </svg>

      {/* 🔮 خلفية الكور المعتمة */}
      <div style={{
        position: "absolute",
        width: "74%",
        height: "74%",
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(0,0,0,0) 20%, #000000f8 90%)",
        border: `1px dashed ${colors.glow}`,
        boxShadow: `inset 0 0 25px ${colors.glow}`,
        zIndex: 3
      }} />

      {/* 🔮 نصوص الـ MP والأرقام */}
      <div style={{
        position: "absolute",
        bottom: "10%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        fontFamily: "'Orbitron', monospace",
        zIndex: 5,
        textShadow: `0 0 10px ${colors.core}, 0 0 20px #000`,
        pointerEvents: "none"
      }}>
        <span style={{ fontSize: "9px", color: colors.core, letterSpacing: "2px", fontWeight: "bold" }}>MP CORE</span>
        <span style={{ fontSize: "18px", color: "#ffffff", fontWeight: "900", marginTop: "1px" }}>
          {manaValue} <span style={{ fontSize: "11px", color: T.muted }}>/ 5000</span>
        </span>
      </div>

      {/* 👤 صورة البطل */}
      <img
        src="/assets/naif.jpg"
        alt="Sung Jin-Woo"
        style={{
          width: "75%",
          height: "75%",
          objectFit: "contain",
          zIndex: 4,
          filter: `drop-shadow(0 0 10px ${colors.glow})`
        }}
      />
    </div>
  );
}

// ─── HOME PAGE ────────────────────────────────────────────────────────────────
export function HomePage({ state, onNavigate }) {
  const rank = rankFromLevel(state.level);
  const todayQuests = state.quests.filter((q) => q.frequency !== "once");
  const remaining = todayQuests.filter((q) => !q.completed).length;
  const colors = getRankColors(rank);

  return (
    <div style={{
      minHeight: "100vh",
      paddingTop: 80,
      padding: "80px 24px 40px",
      maxWidth: 760,
      margin: "0 auto",
      animation: "fadeIn 0.4s ease-out both",
      position: "relative"
    }}>

      {/* الغلاف الرئيسي */}
      <div style={{ ...glass({ padding: 28 }), position: "relative", marginBottom: 20 }}>
        <HudCorners size={14} />

        {/* التوهج الجانبي الخلفي المتناسق ديناميكياً مع الرانك */}
        <div style={{
          position: "absolute", right: 0, top: 0, bottom: 0, width: 240,
          background: `radial-gradient(ellipse at right, ${colors.glow} 0%, transparent 70%)`,
          pointerEvents: "none",
        }} />

        <div style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          gap: 24,
          flexWrap: "nowrap"
        }}>

          {/* القسم الأيسر */}
          <div style={{ flex: 1, minWidth: 0, zIndex: 2 }}>
            <div style={{ marginBottom: 8 }}><RankBadge rank={rank} size={15} /></div>
            <div key={state.level} style={{
              fontFamily: "'Orbitron', monospace", fontSize: 40, fontWeight: 900,
              color: T.text, animation: "levelPop 0.5s ease-out both",
              textShadow: `0 0 30px ${colors.glow}`,
            }}>
              LV. {state.level}
            </div>

            {state.statPoints > 0 && (
              <button onClick={() => onNavigate("STATS")} style={{
                ...glass({ padding: "8px 14px" }),
                border: `1px solid ${colors.glow}`,
                cursor: "pointer", color: colors.core,
                fontFamily: "monospace", fontSize: 11,
                fontWeight: 700, animation: "pulseOpacity 1.6s infinite", marginTop: 12,
              }}>
                لديك {state.statPoints} نقطة مهارة للتوزيع ▶
              </button>
            )}

            <div style={{ marginTop: 20, width: "100%" }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontFamily: "monospace", fontSize: 10, color: T.muted, marginBottom: 6 }}>
                <span>EXP</span><span>{state.exp} / {state.expToNext}</span>
              </div>
              <ExpBar exp={state.exp} expToNext={state.expToNext} />
            </div>
          </div>

          {/* القسم الأيمن */}
          <div style={{
            zIndex: 10,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginRight: "-20px",
            marginTop: "-15px",
            marginBottom: "-15px"
          }}>
            <SungJinWooWithManaCore rank={rank} />
          </div>

        </div>
      </div>

      {/* الـ Stats Grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(130px,1fr))", gap: 10, marginBottom: 20 }}>
        {STAT_KEYS.map((k) => (
          <div key={k} style={{ ...glass({ padding: "12px 14px" }), textAlign: "center" }}>
            <div style={{ fontFamily: "'Orbitron', monospace", fontSize: 20, fontWeight: 700, color: T.purple }}>{state.stats[k]}</div>
            <div style={{ fontFamily: "monospace", fontSize: 9, color: T.muted, letterSpacing: 2, marginTop: 2 }}>{k}</div>
          </div>
        ))}
      </div>

      {/* كارت المهام اليومية */}
      <div onClick={() => onNavigate("QUESTS")} style={{ ...glass({ padding: "18px 20px" }), cursor: "pointer", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ fontFamily: "monospace", fontSize: 10, letterSpacing: 3, color: T.cyan, marginBottom: 4 }}>◈ مهام اليوم</div>
          <div style={{ fontSize: 14, color: T.text }}>{remaining > 0 ? `باقي ${remaining} مهمة لإكمالها` : "كل مهام اليوم مكتملة ✓"}</div>
        </div>
        <div style={{ color: T.purple, fontSize: 18 }}>▶</div>
      </div>
    </div>
  );
}
import { T } from "./tokens";

export const PAGES = ["HOME", "QUESTS", "STATS", "GATES", "RANK", "LOOT"];
export const STAT_KEYS = ["STR", "AGI", "VIT", "INT", "SENSE"];

export const LIMITS = {
  MAX_CUSTOM_QUESTS: 200,
  MAX_EXP_DAILY: 50,
  MAX_EXP_WEEKLY: 100,
  MAX_EXP_GATE: 300,
};

// ─── RANKS ────────────────────────────────────────────────────────────────────
export const RANK_TIERS = [
  { title: "E-RANK", min: 1, color: T.red },
  { title: "D-RANK", min: 10, color: "#9ca3af" },
  { title: "C-RANK", min: 20, color: T.cyan },
  { title: "B-RANK", min: 30, color: T.blue },
  { title: "A-RANK", min: 40, color: T.gold },
  { title: "S-RANK", min: 50, color: T.purple },
  { title: "S+-RANK", min: 65, color: "#67e8f9", top: true },
  { title: "[ ★ ]-RULER", min: 80, color: "#fbbf24", top: true },
  { title: "[ ★ ]-RULER-ELITE", min: 500, color: "#d97706", top: true },
  { title: "[ ♛ ]-MONARCH-GENERAL", min: 1500, color: "#f59e0b", top: true },
  { title: "[ ♛ ]-MONARCH-SUPREME", min: 1000, color: "#b45309", top: true },
  { title: "[ ❂ ]-SHADOW-MONARCH", min: 2000, color: "#7c3aed", top: true },
  { title: "[ ❂ ]-SHADOW-OVERLORD", min: 3000, color: "#6d28d9", top: true },
  { title: "[ ♾ ]-ABSOLUTE", min: 5000, color: "#ffffff", top: true },
];

export function rankFromLevel(level) {
  if (level >= 5000) return { title: "[ ♾ ]-ABSOLUTE", color: "#ffffff", top: true };
  if (level >= 3000) return { title: "[ ❂ ]-SHADOW-OVERLORD", color: "#6d28d9", top: true };
  if (level >= 2000) return { title: "[ ❂ ]-SHADOW-MONARCH", color: "#7c3aed", top: true };
  if (level >= 1000) return { title: "[ ♛ ]-MONARCH-SUPREME", color: "#b45309", top: true };
  if (level >= 1500) return { title: "[ ♛ ]-MONARCH-GENERAL", color: "#f59e0b", top: true };
  if (level >= 500) return { title: "[ ★ ]-RULER-ELITE", color: "#d97706", top: true };
  if (level >= 80) return { title: "[ ★ ]-RULER", color: "#fbbf24", top: true };
  if (level >= 65) return { title: "S+-RANK", color: "#67e8f9", top: true };
  if (level >= 50) return { title: "S-RANK", color: T.purple };
  if (level >= 40) return { title: "A-RANK", color: T.gold };
  if (level >= 30) return { title: "B-RANK", color: T.blue };
  if (level >= 20) return { title: "C-RANK", color: T.cyan };
  if (level >= 10) return { title: "D-RANK", color: "#9ca3af" };
  return { title: "E-RANK", color: T.red };
}

// ─── LOOT ─────────────────────────────────────────────────────────────────────
export const TIERS = ["E", "D", "C", "B", "A", "S", "SS", "SSS"];
export const TIER_COLOR = { E: T.red, D: "#9ca3af", C: T.cyan, B: T.blue, A: T.gold, S: T.purple, SS: "#67e8f9", SSS: T.gold };
export const TIER_TOP = { SS: true, SSS: true };

export const ITEM_POOL = {
  E: ["خنجر صدئ", "حجر مكسور", "كيس جلد بالي"],
  D: ["سيف حديدي", "كوارتز شفاف", "ناب غوبلن"],
  C: ["نصل فولاذي", "شظية ياقوت", "ناب أورك"],
  B: ["سيف الفارس", "جوهرة روبي", "نواة وحش"],
  A: ["النصل الشيطاني", "كريستالة زمردية", "مخلب ملكة النمل"],
  S: ["خنجر باروكا", "ناب كاساكا السام", "جوهرة قلب التنين"],
  SS: ["قاتل الفرسان", "خنجر ملك الشياطين", "كريستالة الظل"],
  SSS: ["نصل الحاكم الواحد", "جوهرة سلطة الحاكم", "جوهرة السيادة"],
};

export const DAILY_WEIGHTS = { E: 45, D: 28, C: 15, B: 7, A: 3.2, S: 1.2, SS: 0.25, SSS: 0.05 };
export const GATE_WEIGHTS = { E: 8, D: 14, C: 18, B: 20, A: 18, S: 13, SS: 6, SSS: 3 };

// ─── GATE DIFFICULTY ──────────────────────────────────────────────────────────
export const GATE_DIFFICULTY = {
  NORMAL: { label: "NORMAL", color: T.cyan, hp: 100, exp: 120, stamina: 30, monsterDmg: [3, 8], dropChance: 0.50, weights: { E: 8, D: 14, C: 18, B: 20, A: 18, S: 13, SS: 6, SSS: 3 } },
  ELITE: { label: "ELITE", color: T.blue, hp: 220, exp: 220, stamina: 45, monsterDmg: [5, 12], dropChance: 0.62, weights: { E: 4, D: 9, C: 14, B: 18, A: 20, S: 18, SS: 11, SSS: 6 } },
  BOSS: { label: "BOSS", color: T.gold, hp: 400, exp: 400, stamina: 65, monsterDmg: [8, 18], dropChance: 0.75, weights: { E: 1, D: 4, C: 8, B: 14, A: 18, S: 22, SS: 20, SSS: 13 } },
  DUNGEON: { label: "DUNGEON", color: T.purple, hp: 650, exp: 600, stamina: 80, monsterDmg: [10, 22], dropChance: 0.90, weights: { E: 0.5, D: 1.5, C: 4, B: 9, A: 15, S: 22, SS: 25, SSS: 23 } },
};

// ─── EQUIPMENT ────────────────────────────────────────────────────────────────
export function itemShapeType(name) {
  if (/سيف|خنجر|نصل|قاتل/.test(name)) return "weapon";
  if (/ناب|مخلب/.test(name)) return "claw";
  if (/نواة/.test(name)) return "orb";
  if (/كيس/.test(name)) return "pouch";
  return "gem";
}

// كل نوع شكل يربط بستات معينة — تجهيز عنصر يرفع تلقائياً الستات المرتبطة به
export const SLOT_STAT = { weapon: "STR", claw: "AGI", orb: "VIT", gem: "INT", pouch: "SENSE" };
export const SLOT_LABEL = { weapon: "سلاح", claw: "مخلب", orb: "نواة", gem: "جوهرة", pouch: "كيس" };
export const SLOT_ORDER = ["weapon", "claw", "orb", "gem", "pouch"];

// قوة البونص الأساسية حسب الرتبة (E=2 ... SSS=16)
export function tierBonusValue(tier) {
  return (TIERS.indexOf(tier) + 1) * 2;
}

// ترقية العنصر: تستهلك نسخاً من نفس العنصر كمواد، كل لفل يرفع قوته
export const UPGRADE_MAX_LEVEL = 10;
export function upgradeCost(level) {
  return level + 2; // يزيد التكلفة كل ما زاد مستوى الترقية
}

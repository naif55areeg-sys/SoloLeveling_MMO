import { TIERS, ITEM_POOL, GATE_DIFFICULTY, SLOT_STAT, tierBonusValue } from "./gameData";

// ─── DATE HELPERS ─────────────────────────────────────────────────────────────
export function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

export function weekKey() {
  const d = new Date();
  const onejan = new Date(d.getFullYear(), 0, 1);
  const week = Math.ceil((((d - onejan) / 86400000) + onejan.getDay() + 1) / 7);
  return `${d.getFullYear()}-W${week}`;
}

// ─── COMBAT ───────────────────────────────────────────────────────────────────
export function rollDamage(str) {
  const min = Math.max(1, str - 2);
  const max = str + 4;
  let dmg = min + Math.floor(Math.random() * (max - min + 1));
  let crit = false;
  if (Math.random() < 0.10) { dmg *= 2; crit = true; }
  return { dmg, crit };
}

export function rollMonsterDamage([min, max]) {
  return min + Math.floor(Math.random() * (max - min + 1));
}

export function maxPlayerHp(stats) {
  return 50 + (stats?.VIT || 10) * 5;
}

export function hpColor(pct) {
  if (pct > 50) return "#10b981";
  if (pct > 20) return "#eab308";
  return "#ef4444";
}

// ─── LOOT ─────────────────────────────────────────────────────────────────────
export function rollLoot(dropChance, weights) {
  if (Math.random() > dropChance) return null;
  const total = TIERS.reduce((sum, t) => sum + weights[t], 0);
  let r = Math.random() * total;
  let chosen = TIERS[0];
  for (const t of TIERS) {
    r -= weights[t];
    if (r <= 0) { chosen = t; break; }
  }
  const pool = ITEM_POOL[chosen];
  const name = pool[Math.floor(Math.random() * pool.length)];
  return { tier: chosen, name };
}

// ─── EQUIPMENT BONUS ──────────────────────────────────────────────────────────
export function itemBonusValue(item) {
  return tierBonusValue(item.tier) + (item.level || 0);
}

export function getEquipmentBonuses(state) {
  const bonuses = { STR: 0, AGI: 0, VIT: 0, INT: 0, SENSE: 0 };
  const equipped = state.equipped || {};
  const inv = state.inventory || [];
  for (const slot of Object.keys(SLOT_STAT)) {
    const key = equipped[slot];
    if (!key) continue;
    const item = inv.find((it) => `${it.tier}-${it.name}` === key);
    if (!item) continue;
    bonuses[SLOT_STAT[slot]] += itemBonusValue(item);
  }
  return bonuses;
}

// الستات الفعلية بعد إضافة بونص التجهيز — تُستخدم بالقتال وحساب الـ HP
export function effectiveStats(state) {
  const bonus = getEquipmentBonuses(state);
  const s = state.stats;
  return {
    STR: s.STR + bonus.STR,
    AGI: s.AGI + bonus.AGI,
    VIT: s.VIT + bonus.VIT,
    INT: s.INT + bonus.INT,
    SENSE: s.SENSE + bonus.SENSE,
  };
}

// ─── EXP / LEVELING ───────────────────────────────────────────────────────────
export function gainExp(state, amount) {
  let { level, exp, expToNext, statPoints } = state;
  exp += amount;
  let leveledUp = 0;
  while (exp >= expToNext) {
    exp -= expToNext;
    level += 1;
    expToNext = Math.round(expToNext * 1.15);
    statPoints += 3;
    leveledUp += 1;
  }
  return { ...state, level, exp, expToNext, statPoints, _leveledUp: leveledUp };
}

// ─── STATE HELPERS ────────────────────────────────────────────────────────────
export function applyResets(state) {
  const t = todayStr(), w = weekKey();
  let changed = false;
  const quests = state.quests.map((q) => {
    if (q.frequency === "daily" && q.completed && q.lastDate !== t) { changed = true; return { ...q, completed: false }; }
    if (q.frequency === "weekly" && q.completed && q.lastDate !== w) { changed = true; return { ...q, completed: false }; }
    return q;
  });
  return changed ? { ...state, quests } : state;
}

export function defaultState() {
  return {
    level: 1,
    exp: 0,
    expToNext: 100,
    statPoints: 0,
    stats: { STR: 1000, AGI: 10, VIT: 10, INT: 10, SENSE: 10 },
    inventory: [],
    equipped: {},
    stamina: 10000,
    lastRest: Date.now(),
    dailyQuestAdds: 0,
    lastAddDate: null,
    playerHp: maxPlayerHp({ VIT: 10 }),
    potions: 9,
    quests: [
      { id: "q1", title: "100 Pushups", type: "DAILY", expReward: 15, frequency: "daily", completed: false, lastDate: null },
      { id: "q2", title: "100 Situps", type: "DAILY", expReward: 15, frequency: "daily", completed: false, lastDate: null },
      { id: "q3", title: "Read 30 minutes", type: "DAILY", expReward: 10, frequency: "daily", completed: false, lastDate: null },
      { id: "q4", title: "Plan the week", type: "WEEKLY", expReward: 40, frequency: "weekly", completed: false, lastDate: null },
      { id: "q5", title: "Finish a side-project milestone", type: "GATE", expReward: GATE_DIFFICULTY.NORMAL.exp, frequency: "once", hp: GATE_DIFFICULTY.NORMAL.hp, maxHp: GATE_DIFFICULTY.NORMAL.hp, difficulty: "NORMAL", completed: false, lastDate: null },
    ],
  };
}

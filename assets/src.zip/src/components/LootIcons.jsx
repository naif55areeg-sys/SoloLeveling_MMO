import { TIER_COLOR } from "../constants/gameData";

// ─── PSEUDO-3D ITEM SHAPES (faceted SVG, gradients & highlights for depth) ───
export function itemShapeType(name) {
  if (/سيف|خنجر|نصل|قاتل/.test(name)) return "weapon";
  if (/ناب|مخلب/.test(name)) return "claw";
  if (/نواة/.test(name)) return "orb";
  if (/كيس/.test(name)) return "pouch";
  return "gem";
}

export function GemShape({ color, size = 56, uid }) {
  const g1 = `gemA-${uid}`, g2 = `gemB-${uid}`;
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" style={{ filter: `drop-shadow(0 6px 10px ${color}66)` }}>
      <defs>
        <linearGradient id={g1} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
          <stop offset="35%" stopColor={color} />
          <stop offset="100%" stopColor={color} stopOpacity="0.55" />
        </linearGradient>
        <linearGradient id={g2} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={color} />
          <stop offset="100%" stopColor="#04000f" stopOpacity="0.9" />
        </linearGradient>
      </defs>
      <polygon points="32,4 48,20 16,20" fill={`url(#${g1})`} stroke="#ffffff40" strokeWidth="0.5" />
      <polygon points="16,20 48,20 40,30 24,30" fill={color} opacity="0.85" stroke="#ffffff40" strokeWidth="0.5" />
      <polygon points="16,20 24,30 8,32" fill={`url(#${g2})`} opacity="0.9" />
      <polygon points="48,20 56,32 40,30" fill={`url(#${g2})`} opacity="0.65" />
      <polygon points="8,32 24,30 32,60" fill={`url(#${g2})`} />
      <polygon points="56,32 40,30 32,60" fill={color} opacity="0.45" />
      <polygon points="24,30 40,30 32,60" fill={color} opacity="0.78" />
      <polygon points="20,17 28,17 24,23" fill="#ffffff" opacity="0.6" />
    </svg>
  );
}

export function WeaponShape({ color, size = 56, uid }) {
  const blade = `bladeG-${uid}`, hilt = `hiltG-${uid}`;
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" style={{ filter: `drop-shadow(0 6px 10px ${color}66)` }}>
      <defs>
        <linearGradient id={blade} x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#94a3b8" />
          <stop offset="45%" stopColor="#f8fafc" />
          <stop offset="58%" stopColor="#cbd5e1" />
          <stop offset="100%" stopColor="#64748b" />
        </linearGradient>
        <linearGradient id={hilt} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor={color} />
          <stop offset="100%" stopColor="#1e0533" />
        </linearGradient>
      </defs>
      <polygon points="32,4 38,9 36,40 32,46 28,40 26,9" fill={`url(#${blade})`} stroke="#ffffff55" strokeWidth="0.6" />
      <rect x="17" y="40" width="30" height="5" rx="2.5" fill={color} />
      <rect x="29" y="45" width="6" height="14" rx="2" fill={`url(#${hilt})`} />
      <circle cx="32" cy="60" r="4" fill={color} stroke="#ffffff80" strokeWidth="0.6" />
    </svg>
  );
}

export function ClawShape({ color, size = 56, uid }) {
  const g = `clawG-${uid}`;
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" style={{ filter: `drop-shadow(0 6px 10px ${color}66)` }}>
      <defs>
        <linearGradient id={g} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#f8fafc" />
          <stop offset="55%" stopColor={color} />
          <stop offset="100%" stopColor="#1e0533" />
        </linearGradient>
      </defs>
      <path d="M18 52 C 13 36, 19 14, 30 5 C 23 22, 21 38, 24 52 Z" fill={`url(#${g})`} stroke="#ffffff40" strokeWidth="0.5" />
      <path d="M35 52 C 32 32, 39 11, 49 5 C 41 22, 41 38, 41 52 Z" fill={`url(#${g})`} stroke="#ffffff40" strokeWidth="0.5" opacity="0.92" />
    </svg>
  );
}

export function OrbShape({ color, size = 56, uid }) {
  const g = `orbG-${uid}`;
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" style={{ filter: `drop-shadow(0 6px 10px ${color}66)` }}>
      <defs>
        <radialGradient id={g} cx="35%" cy="30%" r="65%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="30%" stopColor={color} />
          <stop offset="100%" stopColor="#04000f" />
        </radialGradient>
      </defs>
      <circle cx="32" cy="34" r="24" fill={`url(#${g})`} />
      <ellipse cx="24" cy="24" rx="7" ry="4" fill="#ffffff" opacity="0.55" />
    </svg>
  );
}

export function PouchShape({ color, size = 56, uid }) {
  const g = `pouchG-${uid}`;
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" style={{ filter: `drop-shadow(0 6px 10px ${color}66)` }}>
      <defs>
        <linearGradient id={g} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={color} stopOpacity="0.9" />
          <stop offset="100%" stopColor="#1e0533" />
        </linearGradient>
      </defs>
      <path d="M22 22 Q32 10 42 22 L46 52 Q32 60 18 52 Z" fill={`url(#${g})`} stroke="#ffffff35" strokeWidth="0.6" />
      <rect x="26" y="15" width="12" height="9" rx="4.5" fill="none" stroke={color} strokeWidth="2" />
    </svg>
  );
}

export function ItemIcon({ name, tier, uid, size = 56 }) {
  const color = TIER_COLOR[tier];
  const type = itemShapeType(name);
  const props = { color, size, uid };
  if (type === "weapon") return <WeaponShape {...props} />;
  if (type === "claw") return <ClawShape {...props} />;
  if (type === "orb") return <OrbShape {...props} />;
  if (type === "pouch") return <PouchShape {...props} />;
  return <GemShape {...props} />;
}

import { useState, useEffect } from "react";
import { T } from "../constants/tokens";
import { PAGES } from "../constants/gameData";

// ─── PRELOADER ────────────────────────────────────────────────────────────────
export function Preloader({ onComplete }) {
  const [pct, setPct] = useState(0);
  const [phase, setPhase] = useState("loading");

  useEffect(() => {
    const steps = [
      { target: 28, delay: 0,   speed: 30 },
      { target: 61, delay: 200, speed: 18 },
      { target: 88, delay: 150, speed: 30 },
      { target: 100, delay: 100, speed: 20 },
    ];
    let current = 0, cur = 0;
    function runStep() {
      if (current >= steps.length) { setPhase("reveal"); return; }
      const { target, delay, speed } = steps[current++];
      setTimeout(() => {
        const iv = setInterval(() => {
          cur++; setPct(cur);
          if (cur >= target) { clearInterval(iv); runStep(); }
        }, speed);
      }, delay);
    }
    runStep();
  }, []);

  useEffect(() => {
    if (phase === "reveal") {
      const t = setTimeout(() => { setPhase("done"); onComplete(); }, 700);
      return () => clearTimeout(t);
    }
  }, [phase, onComplete]);

  if (phase === "done") return null;

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 9999, background: T.bg,
      display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 32,
      animation: phase === "reveal" ? "fadeOutShrink 0.6s ease-in-out both" : undefined,
    }}>
      <div style={{ position: "relative", width: 120, height: 120, display: "flex", alignItems: "center", justifyContent: "center" }}>
        {[120, 96].map((d, i) => (
          <div key={d} style={{
            position: "absolute", width: d, height: d, borderRadius: "50%",
            border: `1px solid rgba(139,92,246,${0.2 + i * 0.1})`,
            animation: `pulse-ring ${2 + i * 0.5}s ease-in-out infinite`,
          }} />
        ))}
        <div style={{
          width: 54, height: 54, borderRadius: "50%",
          background: "radial-gradient(circle at 35% 35%, #c084fc, #4c1d95 60%, #1e0533)",
          boxShadow: `0 0 30px ${T.glow}, 0 0 60px ${T.glow}40`,
          animation: "float 3s ease-in-out infinite",
        }} />
      </div>
      <div style={{ fontFamily: "'Orbitron', monospace", fontSize: 20, fontWeight: 900, letterSpacing: 4, color: T.text }}>SYSTEM</div>
      <div style={{ width: 220, height: 2, background: "rgba(139,92,246,0.15)", borderRadius: 1, overflow: "hidden" }}>
        <div style={{ height: "100%", width: `${pct}%`, background: `linear-gradient(90deg, ${T.glowBlue}, ${T.purple}, ${T.cyan})`, transition: "width 0.25s" }} />
      </div>
    </div>
  );
}

// ─── NAV ──────────────────────────────────────────────────────────────────────
export function Nav({ activePage, onNavigate, level, statPoints }) {
  return (
    <nav style={{
      position: "fixed", top: 0, left: 0, right: 0, zIndex: 100,
      background: "rgba(10,4,32,0.72)", backgroundImage: "linear-gradient(165deg, rgba(255,255,255,0.06), transparent 45%)",
      backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)",
      border: `1px solid ${T.border}`, borderLeft: "none", borderRight: "none", borderTop: "none",
      borderRadius: 0, boxShadow: "0 10px 30px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.04)",
      padding: "0 24px", height: 56,
      display: "flex", alignItems: "center", justifyContent: "space-between",
      animation: "navDrop 0.5s ease-out both", flexWrap: "wrap", gap: 8,
    }}>
      <div style={{ fontFamily: "'Orbitron', monospace", fontSize: 13, fontWeight: 700, letterSpacing: 3, color: T.purple, display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ width: 8, height: 8, borderRadius: "50%", background: T.purple, boxShadow: `0 0 8px ${T.purple}` }} />
        SL_SYSTEM
      </div>
      <div style={{ display: "flex", gap: 4 }}>
        {PAGES.map((p) => (
          <button key={p} onClick={() => onNavigate(p)} style={{
            background: activePage === p ? "rgba(139,92,246,0.12)" : "none",
            border: activePage === p ? `1px solid ${T.border}` : "1px solid transparent",
            cursor: "pointer", padding: "6px 12px", borderRadius: 6,
            fontFamily: "'Rajdhani', monospace", fontSize: 11, fontWeight: 600, letterSpacing: 2,
            color: activePage === p ? T.purple : T.muted, transition: "color 0.2s",
          }}>
            {p}{p === "STATS" && statPoints > 0 ? ` (${statPoints})` : ""}
          </button>
        ))}
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 8, fontFamily: "monospace", fontSize: 10, color: T.muted }}>
        <div style={{ width: 6, height: 6, borderRadius: "50%", background: T.green, boxShadow: `0 0 6px ${T.green}` }} />
        LV.{level}
      </div>
    </nav>
  );
}

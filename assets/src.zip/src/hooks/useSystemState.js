import { useState, useEffect, useRef, useCallback } from "react";
import { defaultState, applyResets } from "../constants/gameLogic";

const STORAGE_KEY = "sl-system-state-v1";

export function useSystemState() {
  const [state, setState] = useState(null);
  const [loaded, setLoaded] = useState(false);
  const saveTimer = useRef(null);

  useEffect(() => {
    let s = null;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) s = JSON.parse(raw);
    } catch (e) {
      s = null;
    }
    if (!s) s = defaultState();
    s = applyResets(s);
    setState(s);
    setLoaded(true);
  }, []);

  const persist = useCallback((next) => {
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); } catch (e) { /* ignore */ }
    }, 250);
  }, []);

  const update = useCallback((fn) => {
    setState((prev) => {
      const next = fn(prev);
      persist(next);
      return next;
    });
  }, [persist]);

  return { state, loaded, update };
}
